const express = require("express");
const app = express();

app.set('view engine', 'ejs');

app.get("/", function (req, res) {
    res.render("login");
})
app.post("/", function (req, res) {
    res.render("login");
})

app.post("/index", function (req, res) {
    res.render("index");
})

app.get("/ponto", function (req, res) {
    res.render("ponto");
})

app.post("/ponto", function (req, res) {
    res.render("ponto");
})


app.listen(8888, () => { console.log("NO AR!!!") })



